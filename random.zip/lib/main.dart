import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String _timeString = '';

  @override
  void initState() {
    super.initState();
    // Call updateTime() once to initialize the time string
    updateTime();
  }

  void updateTime() {
    final now = DateTime.now();
    final formatter = DateFormat('HH:mm:ss');
    final timeString = formatter.format(now);
    setState(() {
      _timeString = timeString;
    });
    // Set up a timer to call updateTime() every second
    Timer.periodic(Duration(seconds: 1), (timer) {
      updateTime();
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Clock',
      home: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.orangeAccent, Colors.pinkAccent],
            ),
          ),
          child: Center(
            child: Text(
              _timeString,
              style: TextStyle(
                color: Colors.white,
                fontSize: 50,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
